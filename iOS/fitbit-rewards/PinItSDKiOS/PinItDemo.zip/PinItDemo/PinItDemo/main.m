//
//  main.m
//  PinItDemo
//
//  Created by Naveen Gavini on 2/20/13.
//  Copyright (c) 2013 Pinterest. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PDAppDelegate class]));
    }
}
